# Catter CMS 已知 Bug 模式与修复速查

> 每次遇到问题，先查此表；每次发现新 Bug，更新此表。

---

## 快速索引

| Bug 类型 | 错误信息 | 跳转 |
|---------|---------|------|
| dot 空格问题 | `function "xxx" not defined` | [#B001](#b001) |
| 不存在的字段 | `can't evaluate field xxx` | [#B002](#b002) |
| URL 字段不存在 | `can't evaluate field URL` | [#B003](#b003) |
| 跨文件模板 | `no such template` | [#B004](#b004) |
| asset_path 路径重复 | MIME type error（路径含`//`）| [#B005](#b005) |
| in 函数参数顺序 | `wrong type for value` | [#B006](#b006) |
| range 循环取索引 | `cannot index slice/array` | [#B007](#b007) |
| CSS 变量不生效 | 颜色配置无变化 | [#B008](#b008) |
| FontAwesome 路径 | MIME type error | [#B009](#b009) |
| Google Fonts 加载慢 | 页面加载超时 | [#B010](#b010) |
| ensureSlice 缺失 | `wrong type for value` | [#B011](#b011) |
| 配置 key 不匹配 | 配置不生效（无报错） | [#B012](#b012) |
| 配置分组无标签 | 后台显示"未命名分组" | [#B013](#b013) |
| markdownHTML 未用 | 文章内容显示源码 | [#B014](#b014) |
| 动画关键帧缺失 | 轮播不工作 | [#B015](#b015) |
| 分页字段名错误 | 分页不显示 / nil 错误 | [#B016](#b016) |

---

## B001

**错误信息：** `function "Excerpt" not defined` 或 `function "Title" not defined`

**原因：** Go 模板中 `.` 和字段名之间有空格，被解析为函数调用

```html
<!-- ❌ 错误 -->
{{ . Excerpt }}
{{ . Category.Name }}

<!-- ✅ 修复：紧接写，无空格 -->
{{ .Excerpt }}
{{ .Category.Name }}
```

---

## B002

**错误信息：** `can't evaluate field Cover in type models.Post`

**原因：** 引用了 Post 模型中不存在的字段

**Post 模型实际可用字段：**
```
ID, Title, Slug, Content, Excerpt, Views, Status
PublishedAt, CreatedAt, UpdatedAt
CategoryID, Category{ID,Name,Slug}
AuthorID, Author{ID,Name}
Tags[]{ID,Name,Slug}
MetaTitle, MetaDescription

❌ 不存在：Cover, ReadTime, Thumbnail, Image, CoverImage
```

**修复：** 移除对不存在字段的引用，或用 Excerpt/存在字段替代

---

## B003

**错误信息：** `can't evaluate field URL in type *models.Category`

**原因：** Category/Tag/Post 等模型没有 URL 字段，URL 需要手动拼接

```html
<!-- ❌ 错误 -->
<a href="{{ .Category.URL }}">{{ .Category.Name }}</a>
<a href="{{ .URL }}">{{ .Label }}</a>

<!-- ✅ 修复：手动拼接 -->
<a href="/category/{{ .Category.Slug }}">{{ .Category.Name }}</a>
<a href="/article/{{ .Slug }}">{{ .Title }}</a>
<a href="/tag/{{ .Slug }}">{{ .Name }}</a>
<a href="/page/{{ .Slug }}">{{ .Title }}</a>
```

---

## B004

**错误信息：** `no such template "_head"` 或 `no such template "_footer"`

**原因：** Go html/template 不支持跨文件的 template include

```html
<!-- ❌ 错误：尝试引用外部 partial 模板 -->
{{ template "_head" . }}
{{ template "partials/nav" . }}

<!-- ✅ 修复：每个页面包含完整 HTML 结构（复制粘贴 header/footer） -->
<!DOCTYPE html>
<html lang="zh-CN">
<head>...</head>
<body>
    <header>...</header>  <!-- 每个页面都要写完整 -->
    <main>...</main>
    <footer>...</footer>
</body>
</html>
```

---

## B005

**错误信息：** MIME type error，路径出现 `//themes/xxx//themes/xxx/`

**原因：** `asset_path` 函数自动添加 `/themes/{slug}/` 前缀，传参不要再带此前缀

```html
<!-- ❌ 错误：路径重复 -->
{{ asset_path "/themes/my-theme/assets/css/base.css" }}
<!-- 结果：/themes/my-theme//themes/my-theme/assets/css/base.css -->

<!-- ✅ 修复：只传相对路径 -->
{{ asset_path "assets/css/base.css" }}
<!-- 结果：/themes/my-theme/assets/css/base.css -->
```

---

## B006

**错误信息：** `wrong type for value; expected string; got []interface {}`

**原因：** `in` 函数参数顺序错误（先 item，后 slice）

```html
<!-- ❌ 错误：顺序反了 -->
{{ if in $widgets "profile" }}

<!-- ✅ 修复：in item slice -->
{{ if in "profile" $widgets }}
```

---

## B007

**错误信息：** `cannot index slice/array with type models.Post`

**原因：** 在 range 循环中，`.` 是当前元素（Post 对象），不是索引数字

```html
<!-- ❌ 错误：用 Post 对象当索引 -->
{{ range .posts }}
<span>{{ add (index $.posts .) 1 }}</span>
{{ end }}

<!-- ✅ 修复：用 $index, $item 语法 -->
{{ range $index, $post := .posts }}
<span>{{ add $index 1 }}</span>
<h3>{{ $post.Title }}</h3>
{{ end }}
```

---

## B008

**症状：** 用户在管理后台修改颜色，前台没有变化

**可能原因及修复：**

1. **CSS 变量名与配置 key 不对应**
   ```yaml
   # theme.yml
   - name: primaryDark    # camelCase
   ```
   ```css
   /* base.css */
   --primary-dark: #xxx;  /* kebab-case，对应关系 primaryDark ↔ --primary-dark */
   ```
   ```html
   <!-- 模板中注入用户配置 -->
   <style>:root{ --primary-dark: {{ getConfig "primaryDark" "#0f3460" }}; }</style>
   ```

2. **模板中没有注入 CSS 变量覆盖**
   ```html
   <!-- ✅ 每个模板的 <head> 中必须有 CSS 变量注入块 -->
   <link rel="stylesheet" href="{{ asset_path "assets/css/base.css" }}">
   <style>
   :root {
       --primary: {{ getConfig "primaryColor" "#2563eb" }};
       --primary-dark: {{ getConfig "primaryDark" "#0f3460" }};
   }
   </style>
   ```

3. **CSS 中硬编码颜色（未用变量）**
   ```css
   /* ❌ 错误 */
   .hero { background: #0f3460; }

   /* ✅ 修复 */
   .hero { background: var(--primary-dark); }
   ```

---

## B009

**错误信息：** MIME type error，FontAwesome CSS 被拒绝加载

**原因：** FontAwesome 路径错误

```html
<!-- ❌ 错误路径 -->
<link href="/themes/fontawesome/css/all.min.css">

<!-- ✅ 正确路径（全局路由，不在 themes 目录下） -->
<link rel="stylesheet" href="/fontawesome/css/all.min.css">
```

---

## B010

**症状：** 页面加载极慢，控制台显示 `fonts.googleapis.com` 超时

**原因：** Google Fonts 在国内无法访问

```html
<!-- ❌ 错误：使用 Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC&display=swap">

<!-- ✅ 修复：使用系统字体栈 -->
<!-- 直接删除 Google Fonts link，在 CSS 中设置系统字体 -->
```

```css
/* base.css */
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
                 'Helvetica Neue', Arial, 'Noto Sans SC', sans-serif;
}
```

---

## B011

**错误信息：** `wrong type for value` 或 range 循环报错

**原因：** 从数据库读取的配置值可能已被解析为 `[]interface{}`，直接用 `json_decode` 会出错

```html
<!-- ❌ 错误：直接 json_decode 可能失败 -->
{{ range (json_decode (getConfig "sidebarWidgets" `["profile"]`)) }}

<!-- ✅ 修复：用 ensureSlice 包装 -->
{{ $widgets := ensureSlice (getConfig "sidebarWidgets" `["profile","categories","tags"]`) }}
{{ range $widgets }}
    {{ . }}
{{ end }}
```

---

## B012

**症状：** 管理后台保存配置成功，但前台内容没有变化（无报错）

**排查流程：**
1. 确认模板中使用的 key 与 theme.yml 中 `configDefinition` 的 `name` 完全一致（区分大小写）
2. 检查 `config` 部分是否也定义了该 key（两处必须都有）
3. 检查 `getConfig` 函数的 key 参数是否拼写正确

```yaml
# ✅ 两处必须一致
config:
  postListStyle: "card"           # key 在这里

configDefinition:
  - section: layout
    fields:
      - name: postListStyle       # ← 必须与上面 key 完全一致
```

```html
<!-- ✅ 模板中 key 必须与上面一致 -->
{{ getConfig "postListStyle" "card" }}
```

---

## B013

**症状：** 管理后台主题配置界面显示"未命名分组"

**原因：** `configDefinition` 中缺少 `label` 字段（只有 `section`）

```yaml
# ❌ 错误：没有 label
configDefinition:
  - section: colors
    fields: ...

# ✅ 修复：必须同时有 section 和 label
configDefinition:
  - section: colors
    label: 颜色设置     # ← 必须有 label
    fields: ...
```

---

## B014

**症状：** 文章内容页显示 Markdown 源码（`# 标题` `**粗体**` 等）

**原因：** 文章内容未经过 Markdown 渲染

```html
<!-- ❌ 错误：直接输出原始内容 -->
<div class="article-content">{{ .post.Content }}</div>

<!-- ✅ 修复：使用 markdownHTML + safe 组合 -->
<article class="article-content">
    {{ markdownHTML .post.Content | safe }}
</article>
```

---

## B015

**症状：** CSS 动画/轮播功能不正常（显示空白或只显示第一帧）

**原因：** CSS `animation` 属性和对应的 `@keyframes` 必须同时存在

```css
/* ❌ 错误：有 animation 但无 @keyframes */
.slide { animation: fadeInOut 8s infinite; }
/* 缺少 @keyframes fadeInOut */

/* ✅ 修复：两者必须配套 */
.carousel-slide:nth-child(1) { animation: slideShow 12s infinite 0s; }
.carousel-slide:nth-child(2) { animation: slideShow 12s infinite 4s; }
.carousel-slide:nth-child(3) { animation: slideShow 12s infinite 8s; }

@keyframes slideShow {
    0%, 100% { opacity: 0; }
    8%, 25% { opacity: 1; }
    33%, 99% { opacity: 0; }
}
```

**轮播配置公式（N 张图，总时长 T 秒）：**
- 每张显示时间 ≈ T/N 秒
- 每张延迟：index × (T/N) 秒
- @keyframes 显示区间：`0% 到 (100/N)%`

---

## B016

**症状：** 分页控件不显示，或出现 `nil pointer` 错误

**原因：** 分页字段名是 `pagination`，不是 `paginator`。且字段结构为 `{page, pageSize, total, totalPages}`，没有 `Pages[]` 数组。

```html
<!-- ❌ 错误：字段名错误 -->
{{ .paginator.TotalPages }}
{{ range .paginator.Pages }}

<!-- ✅ 正确：字段名是 pagination，字段是小写 -->
{{ with .pagination }}
    当前第 {{ .page }} 页 / 共 {{ .totalPages }} 页
{{ end }}
```

**⚠️ 注意：**
- `pagination` 只在 `article_list.html` 中存在，其他页面（category、tag、home 等）**没有分页**
- `category.html` 和 `tag.html` 目前返回全量文章，没有分页参数
